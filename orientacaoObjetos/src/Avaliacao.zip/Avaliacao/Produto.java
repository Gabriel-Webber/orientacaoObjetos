package Avaliacao;

public class Produto {
   public String nome;
   public String categoria;
   public double preco;
   public int estoque;
}

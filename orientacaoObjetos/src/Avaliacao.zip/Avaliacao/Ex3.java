package Avaliacao;

public class Ex3 {
    public static void main(String[] args) {
        Classes ex = new Classes();

        ex.fds();

    }
}

package Avaliacao;

public class Ex5 {
    public String modelo;
    public static void main(String[] args) {
        Moto moto = new Moto();
        Carro carro = new Carro();

        moto.exibirInfo();
        carro.ha();
    }
}

package Avaliacao;

public class Ex2 {
    public static void main(String[] args) {
        Classes wasd = new Classes();

        wasd.ler();
    }
}
